# Quiz-Vlajky
Appka ukáže vlajku nejakého štátu a štyri možnosti, hráč musí uhádnuť správny štát.
