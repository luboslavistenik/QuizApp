﻿namespace Quiz_Vlajky.Models
{
    public enum Category
    {
        FIRST,
        SECOND,
    }
}
