﻿namespace Quiz_Vlajky
{
    public partial class AppShell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}