﻿using System;

namespace Quiz_Vlajky.Views
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

    }
}