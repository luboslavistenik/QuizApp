﻿namespace Quiz_Vlajky.Views
{
    public partial class PlayingPage
    {
        public PlayingPage() =>
            InitializeComponent();
    }
}